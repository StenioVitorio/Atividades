
package javaatvstenio25092024;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javaatvstenio25092024.atividade.Atividade;



public class JavaAtvStenio25092024 {

    /**
     * @param args the command line arguments
     */
    static List<Atividade> atvs = new ArrayList<Atividade>();
    
    public static void addTarefa(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Insira o titulo da tarefa: ");
        String titulo = scanner.nextLine();
        System.out.println("Insira a descricao da tarefa: ");
        String descricao = scanner.nextLine();
        atvs.add(new Atividade(titulo, descricao));
    }
    public static void showAtividades(){
    for(Atividade atv:atvs){
        System.out.println(atv.toString());
    }
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean loop = true;
        while(loop){
            System.out.println("Escolha uma opcao, (0)para sair,\n (1)para adcionar tarefa,\n(2)para mostrar tarefas ");
            int opt =scanner.nextInt();
        switch(opt){
            case 0:loop=false; break;
            case 1:addTarefa(); break;
            case 2:showAtividades(); break;
        }
        
                
        }
         
    
     
    }
    
    
}
